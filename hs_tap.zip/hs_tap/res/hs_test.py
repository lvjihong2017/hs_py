import tkinter as tk

# 创建主窗口
root = tk.Tk()
root.title("水平放置两个标签")

# 创建第一个标签并放置
label1 = tk.Label(root, text="标签1", padx=10, pady=5, bg="lightblue")
label1.grid(row=0, column=0, padx=5, pady=5)  # 将标签1放置在第一行第一列，并设置边距

# 创建第二个标签并放置
label2 = tk.Label(root, text="标签2", padx=10, pady=5, bg="lightgreen")
label2.grid(row=0, column=1, padx=5, pady=5)  # 将标签2放置在第一行第二列，并设置边距

# 进入 Tkinter 主事件循环
root.mainloop()
